# 🖐️ Handwritten Digit Recognition

## 📘 Project Overview
This project focuses on recognizing handwritten digits (0–9) using a Convolutional Neural Network (CNN) trained on the MNIST dataset.  
The system takes an image of a handwritten digit as input and predicts the corresponding number with high accuracy.

## 🚀 Features
- Recognizes handwritten digits (0–9)
- Trained using the MNIST dataset
- Uses a Convolutional Neural Network (CNN)
- Includes both training and testing scripts
- Optionally integrated with Streamlit/Flask for a web-based interface

## 🧠 Model Architecture
The CNN model includes:
- Conv2D layers with ReLU activation
- MaxPooling2D for dimensionality reduction
- Flatten and Dense layers for classification
- Softmax activation in the output layer

## 📂 Project Structure
hand_digit_recognition/
│
├── data/
│   └── mnist_data/
│
├── models/
│   └── digit_cnn_model.h5
│
├── static/
├── templates/
│
├── app.py
├── train_model.py
├── predict.py
├── requirements.txt
├── README.md
└── .gitignore

## ⚙️ Installation & Setup

### Step 1: Clone the Repository
```bash
git clone https://github.com/your-username/hand-digit-recognition.git
cd hand-digit-recognition
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Train the Model
```bash
python train_model.py
```

### Step 4: Run the Application
If you are using Streamlit:
```bash
streamlit run app.py
```
If you are using Flask:
```bash
python app.py
```

## 🧾 Requirements
- Python 3.8+
- TensorFlow / Keras
- NumPy
- Matplotlib
- Streamlit or Flask (optional)
- OpenCV (optional for image preprocessing)

## 🖼️ Sample Output
Predicted Digit: 7  
Confidence: 98.6%

## 📊 Model Performance
- Accuracy: ~99% on MNIST test data
- Loss: ~0.03 (after training 5 epochs)

## 👩‍💻 Author
**Konda Harshitha**  
B.Tech CSE (2022–2026), Gouthami Institute of Technology & Management for Women

## 🪪 License
MIT License

## 💡 Future Enhancements
- Improve recognition for user-drawn digits
- Add image preprocessing (noise removal, resizing)
- Deploy model on web or mobile platforms
